package com.example.vibrationmonitor;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Environment;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.Deque;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener, LocationListener {
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private LocationManager locationManager;
    private GraphView graphView;
    private TextView currentText, avgText, maxText, minText, gpsText, statusText;
    private EditText thresholdEdit;
    private boolean monitoring = false;
    private double sum = 0;
    private long count = 0;
    private double max = Double.NEGATIVE_INFINITY;
    private double min = Double.POSITIVE_INFINITY;
    private float gravityX, gravityY, gravityZ;
    private static final float ALPHA = 0.8f;
    private Location lastLocation;
    private final Deque<Sample> preBuffer = new ArrayDeque<>();
    private boolean eventRecording = false;
    private long eventTriggerMs;
    private final List<Sample> eventSamples = new ArrayList<>();
    private double eventThreshold;
    private long lastAlarmMs = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24);
        root.setBackgroundColor(Color.rgb(248,249,251));

        TextView title = new TextView(this);
        title.setText("Vibration Monitor"); title.setTextSize(26); title.setTextColor(Color.BLACK); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1,-2));

        graphView = new GraphView(this);
        root.addView(graphView, new LinearLayout.LayoutParams(-1, 650));

        currentText = stat("현재값: 0.000 g"); avgText = stat("평균값: 0.000 g");
        maxText = stat("최대값: 0.000 g"); minText = stat("최소값: 0.000 g");
        gpsText = stat("GPS: 아직 없음"); statusText = stat("상태: 정지");
        root.addView(currentText); root.addView(avgText); root.addView(maxText); root.addView(minText); root.addView(gpsText); root.addView(statusText);

        LinearLayout specRow = new LinearLayout(this); specRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView specLabel = stat("SPEC (g): "); specRow.addView(specLabel);
        thresholdEdit = new EditText(this); thresholdEdit.setText("0.50"); thresholdEdit.setInputType(2|8192);
        specRow.addView(thresholdEdit, new LinearLayout.LayoutParams(0,-2,1)); root.addView(specRow);

        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button start = new Button(this); start.setText("측정 시작"); start.setOnClickListener(v -> startMonitoring());
        Button stop = new Button(this); stop.setText("정지"); stop.setOnClickListener(v -> stopMonitoring());
        Button events = new Button(this); events.setText("저장 파일"); events.setOnClickListener(v -> showFiles());
        buttons.addView(start,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(stop,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(events,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(buttons);

        TextView note = new TextView(this);
        note.setText("※ 이 앱의 진동값은 스마트폰 내장 가속도센서 기반입니다. 산업용 교정 계측기와 동일한 정확도를 보장하지 않습니다.\n※ SPEC 초과 시 약 3초 전 + 3초 후 데이터를 CSV로 저장합니다.");
        note.setTextSize(13); note.setPadding(0,16,0,0); root.addView(note);

        ScrollView sv = new ScrollView(this); sv.addView(root); setContentView(sv);
    }

    private TextView stat(String s){ TextView t=new TextView(this); t.setText(s); t.setTextSize(18); t.setTextColor(Color.DKGRAY); t.setPadding(0,6,0,6); return t; }

    private void startMonitoring(){
        if(accelerometer==null){ Toast.makeText(this,"가속도 센서를 찾을 수 없습니다.",Toast.LENGTH_LONG).show(); return; }
        monitoring=true; sum=0; count=0; max=Double.NEGATIVE_INFINITY; min=Double.POSITIVE_INFINITY; preBuffer.clear(); eventRecording=false; eventSamples.clear();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
        requestLocation(); statusText.setText("상태: 측정 중");
    }

    private void stopMonitoring(){ monitoring=false; sensorManager.unregisterListener(this); if(locationManager!=null) locationManager.removeUpdates(this); statusText.setText("상태: 정지"); }

    private void requestLocation(){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},100); return; }
        try { locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,1,this); Location l=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER); if(l!=null) onLocationChanged(l); } catch(Exception ignored){}
    }

    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==100 && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) requestLocation(); }

    @Override public void onSensorChanged(SensorEvent e){
        if(!monitoring) return;
        gravityX=ALPHA*gravityX+(1-ALPHA)*e.values[0]; gravityY=ALPHA*gravityY+(1-ALPHA)*e.values[1]; gravityZ=ALPHA*gravityZ+(1-ALPHA)*e.values[2];
        float lx=e.values[0]-gravityX, ly=e.values[1]-gravityY, lz=e.values[2]-gravityZ;
        double g = Math.sqrt(lx*lx+ly*ly+lz*lz)/SensorManager.GRAVITY_EARTH;
        long now=System.currentTimeMillis(); Sample s=new Sample(now,lx,ly,lz,g,lastLocation);
        preBuffer.addLast(s); while(!preBuffer.isEmpty() && now-preBuffer.peekFirst().time>3000) preBuffer.removeFirst();
        sum+=g; count++; max=Math.max(max,g); min=Math.min(min,g);
        currentText.setText(String.format(Locale.US,"현재값: %.3f g",g)); avgText.setText(String.format(Locale.US,"평균값: %.3f g",sum/count)); maxText.setText(String.format(Locale.US,"최대값: %.3f g",max)); minText.setText(String.format(Locale.US,"최소값: %.3f g",min));
        graphView.add((float)g);
        double threshold=parseThreshold();
        if(!eventRecording && g>=threshold && now-lastAlarmMs>5000){ eventRecording=true; eventTriggerMs=now; eventThreshold=threshold; eventSamples.clear(); eventSamples.addAll(preBuffer); alarm(); statusText.setText(String.format(Locale.US,"상태: SPEC 초과 %.3f g",g)); }
        if(eventRecording){ if(eventSamples.isEmpty() || eventSamples.get(eventSamples.size()-1).time!=s.time) eventSamples.add(s); if(now-eventTriggerMs>=3000){ saveEvent(); eventRecording=false; lastAlarmMs=now; statusText.setText("상태: 측정 중 (이벤트 저장 완료)"); }}
    }

    private double parseThreshold(){ try{return Double.parseDouble(thresholdEdit.getText().toString());}catch(Exception e){return 0.5;} }

    private void alarm(){
        try{ new ToneGenerator(AudioManager.STREAM_ALARM,100).startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,600); }catch(Exception ignored){}
        try{ Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE); if(v!=null) v.vibrate(VibrationEffect.createOneShot(700,VibrationEffect.DEFAULT_AMPLITUDE)); }catch(Exception ignored){}
    }

    private void saveEvent(){
        File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"events"); if(!dir.exists()) dir.mkdirs();
        String ts=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date(eventTriggerMs)); File f=new File(dir,"event_"+ts+".csv");
        try(FileWriter w=new FileWriter(f)){
            w.write("timestamp_ms,time,x_ms2,y_ms2,z_ms2,vibration_g,latitude,longitude,accuracy_m,spec_g\n");
            SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS",Locale.US);
            for(Sample s:eventSamples){ String lat="",lon="",acc=""; if(s.loc!=null){lat=String.valueOf(s.loc.getLatitude());lon=String.valueOf(s.loc.getLongitude());acc=String.valueOf(s.loc.getAccuracy());}
                w.write(String.format(Locale.US,"%d,%s,%.5f,%.5f,%.5f,%.5f,%s,%s,%s,%.3f\n",s.time,df.format(new Date(s.time)),s.x,s.y,s.z,s.g,lat,lon,acc,eventThreshold)); }
            Toast.makeText(this,"이벤트 저장 완료: "+f.getName(),Toast.LENGTH_LONG).show();
        }catch(Exception ex){ Toast.makeText(this,"저장 실패: "+ex.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private void showFiles(){
        File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"events"); File[] fs=dir.listFiles();
        StringBuilder sb=new StringBuilder(); if(fs==null||fs.length==0) sb.append("저장된 이벤트가 없습니다."); else for(File f:fs) sb.append(f.getName()).append("\n");
        new AlertDialog.Builder(this).setTitle("저장된 CSV").setMessage(sb.toString()).setPositiveButton("확인",null).show();
    }

    @Override public void onLocationChanged(Location l){ lastLocation=l; gpsText.setText(String.format(Locale.US,"GPS: %.6f, %.6f  (±%.0fm)",l.getLatitude(),l.getLongitude(),l.getAccuracy())); }
    @Override public void onAccuracyChanged(Sensor s,int a){}

    static class Sample { long time; float x,y,z; double g; Location loc; Sample(long t,float x,float y,float z,double g,Location l){this.time=t;this.x=x;this.y=y;this.z=z;this.g=g;this.loc=l==null?null:new Location(l);} }

    static class GraphView extends View {
        Paint grid=new Paint(), line=new Paint(), text=new Paint(); Deque<Float> vals=new ArrayDeque<>();
        GraphView(Context c){super(c); grid.setColor(Color.LTGRAY); grid.setStrokeWidth(1); line.setColor(Color.rgb(31,111,235)); line.setStrokeWidth(4); line.setStyle(Paint.Style.STROKE); text.setColor(Color.DKGRAY); text.setTextSize(30); setBackgroundColor(Color.WHITE);}
        void add(float v){vals.addLast(v); while(vals.size()>240) vals.removeFirst(); invalidate();}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); int w=getWidth(),h=getHeight(); for(int i=1;i<5;i++) c.drawLine(0,h*i/5f,w,h*i/5f,grid); c.drawText("실시간 진동 (g)",20,40,text); if(vals.size()<2)return; float maxv=1f; for(float v:vals) if(v>maxv) maxv=v; float dx=w/(float)Math.max(1,vals.size()-1); float px=0,py=h; int i=0; for(float v:vals){float x=i*dx,y=h-(v/maxv)*(h-60); if(i>0)c.drawLine(px,py,x,y,line); px=x;py=y;i++;}}
    }
}
